#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>
#include <SDL.h>

int fn_SDL();

int sdlGame();
void SDL_LimitFPS(unsigned int limit);

void print2DArray(char** board, int cote, HANDLE* hConsole);
char ** generateBoard(int cote);
int havelife(char** board, int cote);
void newGen(char ** board, int cote);
void game();


int pointer(int * a);
void changePointer(int *a);
int ajout(int a);
void revuePointer();