#include "main.h"

//gcc src/main.c -o bin/prog -I include -L lib -lmingw32 -lSDL2main -lSDL2


int main(int argc, char ** argv){

    
	int a = sdlGame();
	if (a == 1){
		return 1;
	}
	return 0;;
}


//SDL
int fn_SDL(){
	SDL_Window* window = SDL_CreateWindow(
		"GAMELIFE",
		SDL_WINDOWPOS_CENTERED,
		SDL_WINDOWPOS_CENTERED,
		800,
		600,
		SDL_WINDOW_SHOWN

	 );

	if(!window){
		SDL_Log("Failed to create window: %s", SDL_GetError());
		return 1;
	}

	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC);

	if (!renderer) {
        SDL_Log("Failed to create renderer: %s", SDL_GetError());
        return 1;
    }
	
	 SDL_Rect rect;  // Declare an SDL_Rect structure

    // Set the dimensions and position of the rectangle
    rect.x = 10;
    rect.y = 10;
    rect.w = 10;
    rect.h = 10;


	
	int quit = 0;
	SDL_Event event;

	while(!quit){
		while (SDL_PollEvent(&event)){
			if(event.type == SDL_QUIT){
				quit = 1;
			}
		}
	
	// BackGround
    SDL_SetRenderDrawColor(renderer, 230, 230, 230, 200); // White
	SDL_RenderClear(renderer);

	// Front
	SDL_SetRenderDrawColor(renderer, 200, 180, 80,255);

	for(int i = 0; i < 3; i++ ){
		for(int j = 0; j < 3; j++){
			SDL_RenderFillRect(renderer, &rect);
			rect.x = rect.x + rect.w + 2;
		}
		rect.y = rect.y + rect.h + 2;
	}
	SDL_RenderPresent(renderer);
	Sleep(1500);
	}

	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();

	return 0;
}

// SDL and game 
int sdlGame(){
	int cote = 60;
	char ** board = generateBoard(cote);

	board[5][4] = 'x';
	board[5][3] = 'x';
	board[5][5] = 'x';
	board[4][4] = 'x';

	SDL_Window* window = SDL_CreateWindow(
		"GAMELIFE",
		SDL_WINDOWPOS_CENTERED,
		SDL_WINDOWPOS_CENTERED,
		800,
		600,
		SDL_WINDOW_SHOWN

	 );

	if(!window){
		SDL_Log("Failed to create window: %s", SDL_GetError());
		return 1;
	}

	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC);

	if (!renderer) {
        SDL_Log("Failed to create renderer: %s", SDL_GetError());
        return 1;
    }
	

	SDL_Surface *image = NULL; 
	int quit = 0;
	SDL_Event event;

	unsigned int frameLimit = 0;

	frameLimit = SDL_GetTicks() + 16;
	SDL_LimitFPS(frameLimit);

	while(!quit){
		
		while (SDL_PollEvent(&event)){
			if(event.type == SDL_QUIT){
				quit = 1;
			}
		}
	
	// BackGround
	
	while(havelife(board, cote)){
		SDL_LimitFPS(frameLimit);
		newGen(board, cote);
		
		SDL_SetRenderDrawColor(renderer, 230, 230, 230, 200); // White
		SDL_RenderClear(renderer);

		// Front
		SDL_SetRenderDrawColor(renderer, 200, 180, 80,255);
		SDL_Rect rect;  // Declare an SDL_Rect structure

		// Set the dimensions and position of the rectangle
		rect.x = 10;
		rect.y = 10;
		rect.w = 10;
		rect.h = 10;

		for (int i = 0; i < cote; i++){
			rect.x = 10;
			for (int j = 0; j < cote; j++){
				if(board[i][j] == 'x'){
					SDL_RenderFillRect(renderer, &rect);
				}
				else{
					 SDL_RenderDrawRect(renderer, &rect);
				}
			rect.x = rect.x + rect.w + 2;
			}
			rect.y = rect.y + rect.h + 2;
		}


		SDL_RenderPresent(renderer);

	
		}
	}

	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();

	return 0;
}

void SDL_LimitFPS(unsigned int limit){
	unsigned int ticks = SDL_GetTicks();

	if (limit<ticks){
		return;
	
	}else if(limit > ticks + 16){
		SDL_Delay(16);
	}
	else{
		SDL_Delay(limit - ticks);
	}

	printf("%d", ticks);
}
  
//Jeu de la vie 
void game(){
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, FOREGROUND_INTENSITY);

	int cote = 15;
	char ** board = generateBoard(cote);

	board[5][4] = 'x';
	board[5][3] = 'x';
	board[5][5] = 'x';
	board[4][4] = 'x';

	while(havelife(board, cote)){
		print2DArray(board, cote, hConsole);
		newGen(board, cote);
		printf("\n");
		Sleep(1500);
	}

	for (int i = 0; i < cote; i++) {
		free(board[i]);
	}
	free(board);
}

char ** generateBoard(int cote){

	char** board = (char**)malloc(cote * sizeof(char*));

    for (int i = 0; i < cote; i++) {
        char* ligne = (char*)malloc((cote + 1) * sizeof(char)); 
        for (int j = 0; j < cote; j++) {
            ligne[j] = 'o'; 
        }
        ligne[cote] = '\0'; 
        board[i] = ligne;
    }
	return board;
}


void print2DArray(char** board, int cote, HANDLE* hConsole) {
	
    for (int i = 0; i < cote; i++) {
        for (int j = 0; j < cote; j++) {
			if (board[i][j]  == 'x'){
				SetConsoleTextAttribute(hConsole, FOREGROUND_RED);
			}
			else {
				SetConsoleTextAttribute(hConsole,  FOREGROUND_GREEN );
			}
			
            printf("%c ", board[i][j]);
			SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

        }
        printf("\n");
    }
}

int havelife(char** board, int cote){
	int count = 0;
	for (int i = 0; i < cote; i++) {
        for (int j = 0; j < cote; j++) {
			if(board[i][j] == 'x'){
				count ++;
				break;
			}
			if(count != 0){
				break;
			}
        }
        
    }
	return count != 0;
}

void newGen(char ** board, int cote){
	char** newBoard = (char**) malloc(cote * sizeof(char*));
	for (int i = 0; i < cote; i++) {
		newBoard[i] = (char*) malloc(cote * sizeof(char)); // Allocate memory for each row
		for (int j = 0; j < cote; j++) {
			int count = 0;
			for (int x = -1; x <= 1; x++) {
				for (int y = -1; y <= 1; y++) {
					if (x == 0 && y == 0) continue;
					int coorX = i + x;
					int coorY = j + y;
					if (coorX >= 0 && coorX < cote && coorY >= 0 && coorY < cote) {
						if (board[coorX][coorY] == 'x') {
							count++;
						}
					}
				}
			}
			if (count == 3) {
				newBoard[i][j] = 'x';
			}
			else if (count == 2) {
				newBoard[i][j] = board[i][j];
			}
			else {
				newBoard[i][j] = 'o';
			}
		}
	}
	
	board = newBoard;
	for (int i = 0; i < cote; i++) {
		free(newBoard[i]);
	}
	free(newBoard);

}

//Revesion 
int pointer(int * a){
	return *a + 3;
}

void changePointer(int *a){
	*a = 6;
}

int ajout(int a){
	return a + 4;
}

void revuePointer(){
	int a = 3;
	int *adresse = &a;
	printf("l'address de a = %d \n", adresse);
	int b = pointer(&a);
	printf("Ne change pas a = %d,  b = %d\n", a, b );
	ajout(a);
	changePointer(&a);
	printf("Ici on change la valeur de a il est par consequent modifier a = %d\n", a);
}